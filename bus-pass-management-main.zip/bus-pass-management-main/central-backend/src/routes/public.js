import { Router } from "express";

const publicRoutes = Router();

export default publicRoutes;
