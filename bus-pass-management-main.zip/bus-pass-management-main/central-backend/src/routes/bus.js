import { Router } from "express";
const busRouter = Router();
// busRouter.get("/verify-user")
busRouter.get("");
