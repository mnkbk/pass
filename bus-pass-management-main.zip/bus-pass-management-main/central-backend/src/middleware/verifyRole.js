export default function verifyRole(req, res, next) {
  try {
  } catch (err) {}
}
