import DashBoard from "./pages/Dashboard/Dashboard";

export default function App() {
  return (
    <>
      {/* <TabsLayout /> */}
      <DashBoard />
      {/* <RegisterForm /> */}
      {/* <Login /> */}
      {/* <Register /> */}
    </>
  );
}
