export const BACKEND_BASE_URL = import.meta.env.VITE_BACKEND_BASE_URL;
