import { useState } from "react";

export default function useRenewPass() {
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
}
